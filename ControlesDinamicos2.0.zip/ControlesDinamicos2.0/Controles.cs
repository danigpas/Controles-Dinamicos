﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlesDinamicos2._0
{
    internal class Controles
    {
        #region Inicialización de variables
        int AnchoVentana;
        int AltoVentana;
        int AnchoEstandar = 25;
        int AnchoGroupBox = 250;
        int AltoGroupBox = 100;

        string Nuevo_Texto = "&Nuevo";
        string Grabar_Texto = "&Grabar";
        string Borrar_Texto = "&Borrar";
        string Principio = "<<";
        string Anterior = "<";
        string siguiente = ">";
        string Final = ">>";
        int AnchoMaxPermitido = 1485;
        int AltoMaxPermitido = 1010;
        #endregion

        /// <summary>
        /// Metodo que crea un tabcontrol y le asigna los valores pasados por parametros
        /// </summary>
        /// <param name="formi"></param>
        /// <param name="name"></param>
        /// <param name="tamaño"></param>
        /// <param name="Location"></param>
        /// <returns>
        /// Devuelve el tabcontrol ya añadido al Form pasado por parametro
        /// </returns>
        public TabControl CreaTabControl(Form1 formi, string name, Size tamaño, Point Location)
        {
            TabControl tabControl = new TabControl();
            tabControl.Name = name;
            tabControl.Size = tamaño;
            tabControl.Location = Location;
            //tabControl.Anchor = AnchorStyles.Left;
            tabControl.Dock = DockStyle.Left;
            tabControl.ItemSize = new Size(100, 30);


            //Una vez pestañas y tabcontrol creados, lo añadimos al form
            formi.Controls.Add(tabControl);

            return tabControl;
        }

        /// <summary>
        /// Metodo que crea una TabPage
        /// </summary>
        /// <param name="tabControl"></param>
        /// <param name="name"></param>
        /// <param name="text"></param>
        /// <returns>
        /// Devuelve la TabPage inicializada y añadida al Tabcontrol pasado por parametro
        /// </returns>
        public TabPage CreaTabPages (TabControl tabControl, string name, string text)
        {
            TabPage page = new TabPage();
            page.Name = name;
            page.Text = text;

            tabControl.TabPages.Add(page);
            return page;
        }

        /// <summary>
        /// Metodo que crea un datagridview
        /// </summary>
        /// <param name="name"></param>
        /// <param name="tamaño"></param>
        /// <param name="localizacion"></param>
        /// <returns> 
        /// devuelve el datagridview ya inicializado con los parametros
        /// </returns>
        public DataGridView CreaDatagridView (string name, Size tamaño,Point localizacion)
        {
            DataGridView dataGridView = new DataGridView();
            dataGridView.Name = name;
            dataGridView.Size = tamaño;
            dataGridView.Location = localizacion;

            return dataGridView;
        }

        /// <summary>
        /// Metodo que crea un GroupBox que incluye una texbox y un boton, situados arriba a la derecha en la ventana
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="miformulario"></param>
        public GroupBox CreaGrb_Busqueda(string nombre, Form1 miformulario)
        {
            //Debug.WriteLine("GroupBoxBusqueda llamado");
            miformulario.SuspendLayout();
            miformulario.Size = new Size(AnchoMaxPermitido, AltoMaxPermitido);
            //miformulario.Size = Screen.PrimaryScreen.WorkingArea.Size;
            //miformulario.Size = new Size(800, 600);
            //miformulario.WindowState = FormWindowState.Maximized;
            AnchoVentana = miformulario.Width;
            AltoVentana = miformulario.Height;


            // Crear GroupBox
            GroupBox grb_Busqueda = new GroupBox();
            grb_Busqueda.Name = nombre;
            grb_Busqueda.Text = "Buscar :";
            grb_Busqueda.Size = new Size(250, 100);
            //grb_Busqueda.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            grb_Busqueda.Location = new Point((AnchoVentana - grb_Busqueda.Width) - AnchoEstandar, AnchoEstandar);
            grb_Busqueda.AutoSize = true;
            //grb_Busqueda.Dock = DockStyle.Right;
            grb_Busqueda.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            // Crear TextBox
            TextBox txt_BarraBusqueda = new TextBox();
            txt_BarraBusqueda.Name = "txt_BarraBusqueda";
            txt_BarraBusqueda.Location = new Point(10, 20);
            txt_BarraBusqueda.Size = new Size(150, 20);
            txt_BarraBusqueda.AutoSize = true;

            // Crear Button
            Button btn_Busqueda = new Button();
            btn_Busqueda.Name = "btn_Busqueda";
            btn_Busqueda.Text = "B&uscar";
            btn_Busqueda.Location = new Point(txt_BarraBusqueda.Location.X + txt_BarraBusqueda.Width + 5, txt_BarraBusqueda.Location.Y);
            btn_Busqueda.Size = new Size(20, 20);
            btn_Busqueda.AutoSize = true;

            grb_Busqueda.Controls.Add(txt_BarraBusqueda);
            grb_Busqueda.Controls.Add(btn_Busqueda);

            miformulario.Controls.Add(grb_Busqueda);
            //Debug.WriteLine("GroupBox añadido al formulario: " + miformulario.Name);
            miformulario.ResumeLayout();

            return grb_Busqueda;
        }

        public Button CreaBoton(string nombre, string texto)
        {
            Button btn_1 = new Button();
            btn_1.Name = nombre;
            btn_1.Text = texto;
            btn_1.Location = new Point(20, 20);
            btn_1.Size = new Size(20, 20);
            btn_1.AutoSize = true;

            return btn_1;

        }

        /// <summary>
        /// Metodo que crea un FlowLayoutPanel con la botonera de control (nuevo, editar, etc)
        /// </summary>
        /// <param name="miformulario"></param>
        public FlowLayoutPanel CreaFlowLayoutPanel(Form1 miformulario, EventHandler evento)
        {
            int CoordenadaX_grb_Busqueda = AnchoVentana - AnchoGroupBox - AnchoEstandar;
            int coordenadaY = (AltoGroupBox) + 50;
            FlowLayoutPanel flp_Botonera = new FlowLayoutPanel();
            flp_Botonera.Name = "flp_Botonera";
            flp_Botonera.Text = "";
            flp_Botonera.Size = new Size(AnchoGroupBox, 300);
            flp_Botonera.Location = new Point(CoordenadaX_grb_Busqueda, coordenadaY);
            flp_Botonera.AutoSize = true;
            flp_Botonera.BorderStyle = BorderStyle.FixedSingle;
            flp_Botonera.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

            //flp_Botonera.Dock = DockStyle.Right;


            //flp_Botonera.FlowDirection = FlowDirection.TopDown;
            ////flp_Botonera.WrapContents = false;
            //foreach (Button button in flp_Botonera.Controls)
            //{
            //    button.Anchor = AnchorStyles.None;
            //    button.Margin = new Padding(0, (flp_Botonera.Height - button.Height) / 2, 0, 0);
            //}
            Flujo flujo = new Flujo();
            // Crear FlowLayoutPanel
            Button btn_Nuevo = CreaBoton("btn_Nuevo", Nuevo_Texto);
            btn_Nuevo.Click += new EventHandler(flujo.btn_Nuevo_Click);

            Button btn_Grabar = CreaBoton("btn_Grabar", Grabar_Texto);
            btn_Grabar.Click += new EventHandler(evento);

            Button btn_Borrar = CreaBoton("btn_Borrar", Borrar_Texto);
            btn_Borrar.Click += new EventHandler(evento);

            Button btn_Principio = CreaBoton("btn_Principio", Principio);
            btn_Principio.Click += new EventHandler(evento);

            Button btn_Anterior = CreaBoton("btn_Anterior", Anterior);
            btn_Anterior.Click += new EventHandler(evento);

            Button btn_Siguiente = CreaBoton("btn_Siguiente", siguiente);
            btn_Siguiente.Click += new EventHandler(evento);

            Button btn_Final = CreaBoton("btn_Final", Final);
            btn_Final.Click += new EventHandler(evento);
            // Button btn_Consulta = CreaBoton(Consulta);

            AnchoVentana = miformulario.Width;




            //flp_Botonera.Location = new Point((AnchoVentana - flp_Botonera.Width) - AnchoEstandar, CoordenadaY_grb_Busqueda + AnchoGroupBox + AnchoEstandar);
            AñadeBotonesAlFlowLayout(btn_Nuevo, flp_Botonera);
            AñadeBotonesAlFlowLayout(btn_Grabar, flp_Botonera);
            AñadeBotonesAlFlowLayout(btn_Borrar, flp_Botonera);
            AñadeBotonesAlFlowLayout(btn_Principio, flp_Botonera);
            AñadeBotonesAlFlowLayout(btn_Anterior, flp_Botonera);
            AñadeBotonesAlFlowLayout(btn_Siguiente, flp_Botonera);
            AñadeBotonesAlFlowLayout(btn_Final, flp_Botonera);
            // AñadeBotonesAlFlowLayout(btn_Consulta, flp_Botonera);
            flp_Botonera.SetFlowBreak(btn_Nuevo, true);
            flp_Botonera.SetFlowBreak(btn_Grabar, true);
            flp_Botonera.SetFlowBreak(btn_Borrar, true);
            flp_Botonera.SetFlowBreak(btn_Final, true);
            miformulario.Controls.Add(flp_Botonera);

            return flp_Botonera;
        }

        /// <summary>
        /// Metodo que añade botones a un flowlayoutpanel
        /// </summary>
        /// <param name="btn"></param>
        /// <param name="flow"></param>
        public void AñadeBotonesAlFlowLayout(Button btn, FlowLayoutPanel flow)
        {
            flow.Controls.Add(btn);
        }


    }
}
