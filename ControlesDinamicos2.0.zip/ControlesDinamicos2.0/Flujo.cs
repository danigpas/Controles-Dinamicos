﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlesDinamicos2._0
{
    
    internal class Flujo
    {
        #region Datos Conexion a la BBDD
        static string StringConexionTabla = "server=localhost;port=3306;uid=root;pwd='';database=gestion_almacen";
        //MySqlConnection ConexionTabla = new MySqlConnection(StringConexionTabla);
        #endregion

        int AnchoEstandar = 25;
        int AnchoGroupBox = 250;
        int AltoGroupBox = 100;

        string NombreTabControl = "tb_Principal";

        TabControl tb_Principal = new TabControl();
        Size TamañoTabControl;
        Point LocalizacionTabControl;

        DataGridView dg_Tabla = new DataGridView();
        TabPage tbpage_Tabla;
        bool CreaDataGridDatos = true;

        Point localizacion_dg_Tabla = new Point(1,1);
        Size tamaño_dg_Tabla = new Size(200,200);

        DataTable dt_Tabla = new DataTable();

        static FlowLayoutPanel flp_Datos = new FlowLayoutPanel();
        TabPage tbpage_Datos;

        Controles control = new Controles();
        Funciones fun = new Funciones();

        string Nombregrp_Busqueda = "grb_Busqueda";
        GroupBox grb_Busqueda = new GroupBox();

        TextBox txt_Busqueda;
        static BindingSource binding;
        static string NombreTabla = "";

        /// <summary>
        /// MEtodo que resume el flujo del proyecto
        /// </summary>
        /// <param name="form"></param>
        public void FlujoPrograma(Form1 form) 
        {
            
            ConfiguraTabControl(form);
            ConfiguraGroupBox(form);
            Configura_flp_Botonera(form);
            
            
        }

        public Flujo()
        {
            binding = new BindingSource();
            
        }

        /// <summary>
        /// Metodo que configura el tabcontrol de la pestaña
        /// </summary>
        /// <param name="form"></param>
        public void ConfiguraTabControl(Form1 form)
        {
            

            //Primero inicializamos las variables para configurar el tabcontrol 
            TamañoTabControl = new Size(form.Width - AnchoGroupBox - AltoGroupBox, form.Height - AltoGroupBox);
            LocalizacionTabControl = new Point(AnchoEstandar, AnchoEstandar);

            //Ahora llamamos al metodo y creamos el tabcontrol
             tb_Principal = control.CreaTabControl(form,NombreTabControl,TamañoTabControl,LocalizacionTabControl);

            //Ahora vamos a crear las 3 pestañas del tabcontrol
            control.CreaTabPages(tb_Principal, "tbpage_Menu", "Menu");
            control.CreaTabPages(tb_Principal, "tbpage_Tabla", "Tabla");
           tbpage_Datos= control.CreaTabPages(tb_Principal, "tbpage_Datos", "Datos");
            
            //Vamos a crear aqui dentro el flp que va a contener todos los texbox que se crean con la tabla
            flp_Datos.Name = "flp_Datos";
            flp_Datos.Text = ""; 
            flp_Datos.Size = new Size(1, 1);
            flp_Datos.Location = new Point(1, 1);
            flp_Datos.BorderStyle = BorderStyle.FixedSingle;
            tbpage_Datos.Controls.Add(flp_Datos);
            flp_Datos.Dock = DockStyle.Fill;
            


        }

        /// <summary>
        /// Metodo que establece un dataTable con los datos de la tabla pasada por parametro y luego lo asocia al datagridview de la pestaña tabla
        /// </summary>
        /// <param name="nombre_campo"></param>
        public void AbreTablaGestion_Almacen(string nombre_campo,TabControl pepiyo)
        {
            NombreTabla = "";
            NombreTabla = nombre_campo;
            dt_Tabla.Dispose();
            DataTable data = new DataTable();
            string consulta = "SELECT * FROM " + nombre_campo;

            MySqlConnection conexionTabla = new MySqlConnection(StringConexionTabla);
            
            conexionTabla.Open();

            MySqlCommand miCommando = new MySqlCommand(consulta, conexionTabla);

            MySqlDataAdapter adapter = new MySqlDataAdapter(miCommando);
                
            adapter.Fill(data);
            binding.DataSource = data;
            
                
                
            

            if (data.Rows.Count > 0)
            {
                ConfiguraDg_Tabla(data,pepiyo);
                
                //dg_Tabla.DataSource = dt_Tabla;
                //dg_Tabla.Refresh();
            }
            else
            {
                MessageBox.Show("No se encontraron datos.");
            }
            fun.CrearLabelsYTextBoxes(dg_Tabla,flp_Datos);
            //tbpage_Datos.Controls.Add(flp_Datos);
            conexionTabla.Close();
        }

       

        
        /// <summary>
        /// Metodo que configura y crea el datagridview de la pestaña tabla con un datatable ya rellenado anteriormente
        /// </summary>
        /// <param name="dt_Tabla"></param>
        public void ConfiguraDg_Tabla(DataTable taba,TabControl pepe)
        {
            //Creamos una instancia de form1 para buscar el tabcontrol
            //Form1 Ventana = new Form1(false);

            
            //tb_Principal = ConfiguraTabControl(Ventana);
            //Control miComponente = Ventana.Controls["tb_Principal"];
            //TabControl tabControl = (TabControl)miComponente;

            tb_Principal = pepe;
           tbpage_Tabla = tb_Principal.TabPages["tbpage_Tabla"];
            

           
            tb_Principal.SelectedTab = tbpage_Tabla;
            
            if (CreaDataGridDatos) { 
            //Ahora vamos a crear el datagridview de la pestaña tabla y añadirlo a ella
             dg_Tabla= control.CreaDatagridView("dg_Tabla", tamaño_dg_Tabla, localizacion_dg_Tabla);
            dg_Tabla.AutoGenerateColumns = true;
            //dg_Tabla.DataSource = dt_Tabla;

            tbpage_Tabla.Controls.Add(dg_Tabla);

            //Ahora vamos a configurarlo para que ocupe toda la pestaña
            dg_Tabla.Dock = DockStyle.Fill;
            dg_Tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                CreaDataGridDatos = false;
                
            }
            //Ahora enlazamos el datatable con nuestro datagridview
            //dg_Tabla.DataSource = taba;

            
            dg_Tabla.DataSource = binding;
            dg_Tabla.Refresh();
            
            //MessageBox.Show("Esta añadiendo el datagridview " + dg_Tabla.Name +" a la pestaña del tabpage con nombre: " + tbpage_Tabla.Name );
        }

        public void ConfiguraGroupBox(Form1 form)
        {
            //Inicializamos el group box area busqueda
            grb_Busqueda = control.CreaGrb_Busqueda(Nombregrp_Busqueda, form);

            //Ahora buscamos los dos componentes para poder trabajar con sus eventos
            Button btn_Busqueda =(Button) grb_Busqueda.Controls["btn_Busqueda"];
             txt_Busqueda = (TextBox)grb_Busqueda.Controls["txt_BarraBusqueda"];

            btn_Busqueda.Click += new EventHandler(btn_Busqueda_Click);
            txt_Busqueda.KeyPress += new KeyPressEventHandler(txt_Busqueda_KeyPress);
        }

        private void btn_Busqueda_Click(object sender, EventArgs e)
        {
            //PermiteSelectionChanged = false; //De esta forma evitamos que acceda el evento selection changed del datagrid y de errores

            //if (txt_Busqueda.Text == string.Empty)
            //{
            //PermiteSelectionChanged = true;
            //}
            RealizaBusqueda();
        }

        private void txt_Busqueda_KeyPress(object sender, KeyPressEventArgs e)
       {
            if (e.KeyChar == 13) //La keychar 13 es el codigo ascii de la tecla  intro o enter en inglés IMPORTANTE
            {
                // dg_Tabla.DataSource = fun.Buscar_Completo(txt_Busqueda.Text);
                //txt_Total.Text = DA.TotalRegistros(MiEnlace);
                RealizaBusqueda();
                if (txt_Busqueda.Text == string.Empty)
                {
                    //PermiteSelectionChanged = true;
                }
            }
        }

       public void Configura_flp_Botonera(Form1 form)
        {
             FlowLayoutPanel flp_Botonera = control.CreaFlowLayoutPanel(form, BotonesParaNavegar);
        }

        public DataGridView Busca_dg_Datos()
        {

            //Primero vamos a buscar nuestro datagridview
            //Control componenteprueba = form.Controls[NombreTabControl];
            //TabControl tbNavegar = (TabControl)componenteprueba;

            TabPage PestañaTabla = (TabPage)tb_Principal.TabPages["tbpage_Tabla"];

            DataGridView dataNavegar = (DataGridView)PestañaTabla.Controls["dg_Tabla"];

            return dataNavegar;
        }

        public DataTable TablaDatos()
        {

            //Primero vamos a buscar nuestro datagridview
            //Control componenteprueba = form.Controls[NombreTabControl];
            //TabControl tbNavegar = (TabControl)componenteprueba;

            DataTable MiTabla = new DataTable();
            TabPage PestañaTabla = (TabPage)tb_Principal.TabPages["tbpage_Tabla"];

            DataGridView dataNavegar = (DataGridView)PestañaTabla.Controls["dg_Tabla"];

            MiTabla = dataNavegar.DataSource as DataTable;

            return MiTabla;
        }



        private void BotonesParaNavegar(object sender, EventArgs e)
        {
            Button button = sender as Button;
            string buttonName = button.Text;
            // dg_Tabla=(DataGridView)tb_Principal.Controls["dg_Tabla"];

            //dg_Tabla.DataSource = TablaDatos();
            //dg_Tabla.DataSource = binding;
            BindingSource bindinavega = new BindingSource();
            switch (buttonName)
            {
               

                case "<<": //btn_Principio
                    //PermiteSelectionChanged = true;
                    
                    bindinavega.DataSource = fun.NavegarRegistros(binding, "inicio");
                    dg_Tabla.DataSource = bindinavega.DataSource;
                    break;

                case "<": //btn_Anterior
                          //PermiteSelectionChanged = true;
                    bindinavega.DataSource = fun.NavegarRegistros(binding, "retroceder");
                    dg_Tabla.DataSource = bindinavega.DataSource;
                    break;

                case ">": //btn_Siguiente
                    //PermiteSelectionChanged = true;
                    bindinavega.DataSource = fun.NavegarRegistros(binding, "avanzar");
                    dg_Tabla.DataSource = bindinavega.DataSource;
                    break;

                case ">>": //btn_Final
                    //PermiteSelectionChanged = true;
                    bindinavega.DataSource = fun.NavegarRegistros(binding, "fin");
                    dg_Tabla.DataSource = bindinavega.DataSource;
                    break;
            }
        }

        public void RealizaBusqueda()
        {
            //dg_Tabla.Dispose();
            DataTable prueba2 = new DataTable();
            //prueba2.Clear();
            prueba2 = (DataTable)binding.DataSource;
            
            //Primero vamos a crear los parametros que necesitamos pasarle al metodo buscar

            // NombreTabla = fun.ObtenerNombreTabla(dg_Tabla); //Aqui ya sabemos que tabla tiene abierta el datagridview

            string[] NombreColumnas = new string[] { };
            NombreColumnas = fun.ObtenerNombresColumnas(prueba2); //Aqui ya tenemos guardados todos los nombres de nuestras columnas abiertas en un string

            
            DataTable ResultadoBusqueda = new DataTable();
            ResultadoBusqueda = fun.Buscar_Completo(txt_Busqueda.Text, NombreTabla, NombreColumnas);
            //binding.Clear(); 
            binding.DataSource = ResultadoBusqueda;
        }

        public void btn_Nuevo_Click(object sender, EventArgs e)
        {
            fun.VaciaTextBoxes(flp_Datos);
        }

        public void btn_Grabar_Click(object sender, EventArgs e)
        {

        }

        public void btn_Borrar_Click(object sender, EventArgs e)
        {

        }
    }
}

//Metodo abretablas anterior

//DataTable dataTable = new DataTable();
//dataTable.Dispose();
//DataTable dt_Tabla = new DataTable();

//string Consulta = "SELECT * FROM " + nombre_campo;
//ConexionTabla.Open();

//MySqlCommand MiCommando = new MySqlCommand(Consulta, ConexionTabla);
//MySqlDataAdapter adapter = new MySqlDataAdapter(MiCommando);

//adapter.Fill(dt_Tabla);
//MySqlDataReader reader = MiCommando.ExecuteReader();

//if (reader.HasRows)
//{
//    reader.Read();
//}
//else
//{
//    MessageBox.Show("Error al mostrar datos");
//}
//reader.Close();
//ConexionTabla.Close();

////return dt_Tabla;
//dg_Tabla.DataSource = dt_Tabla;