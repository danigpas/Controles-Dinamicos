﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SqlClient;

namespace ControlesDinamicos2._0
{
    internal class Funciones
    {
        DataTable dt = new DataTable();
        string MiConsulta;

        #region Datos Conexion BBDD Funciones
        static string ConectionStringFunciones= "server=localhost;port=3306;uid=root;pwd='';database=gestion_almacen";
        MySqlConnection MiConexion = new MySqlConnection(ConectionStringFunciones);
        MySqlCommand MiCommand = new MySqlCommand();
        #endregion
      

        public string[] ArrayLimpiaEspaciosCadena(string CadenaBuscar)
        {
            string[] palabras = CadenaBuscar.Trim().Split(' '); //Hemos dicho que coja sin espacios por la derecha ni izquierda (el trim) y me divida por espacios y me vaya añadiendo al array

            string[] palabra = new string[palabras.Count()]; //aqui hemos creado otro arrays del tamaño de tantos valores tenga el array
            int contador = 0;
            foreach (string dato in palabras) //Y aqui le hemos dicho que si el valor es un espacio en blanco pase de el y asi tenemos un array solo con los valores reales
            {
                if (dato != "")
                {
                    palabra[contador] = dato;
                    contador++;
                }
            }
            //int contadorPalabras = palabra.Count();
            //En este punto hemos conseguido un array de strings con exactamente las palabras de la busqueda, ahora ya podemos trabajar con ello

            return palabra;
        }

        public string StringLimpiaEspaciosCadena(string cadena)
        {

            string[] CadenaIntermedia = ArrayLimpiaEspaciosCadena(cadena);
            string CadenaFinal = "";

            foreach (string dato in CadenaIntermedia)
            {
                CadenaFinal = dato + " ";
            }
            return CadenaFinal.Trim(); //Asi devolvemos la cadena sin el espacio al final qe le mete el foreach
        }

        private void EjecutaComando() //Como en todos los metodos estabamos introduciendo estos parametros para conectarnos a la base de datos, creamos un metodo que lo haga una vez y lo llamamos las veces que queramos. Para evitar errores lo hacemos privado para que no pueda cambiar
        {
            MiConexion.Open();
            MiCommand.Connection = MiConexion;
            MiCommand.CommandText = MiConsulta;
            MiCommand.ExecuteNonQuery();
            MiConexion.Close();

            //MiCommand = new MySqlCommand(MiConsulta);


        }
        public DataTable Rellenar_Rejilla(string Consulta) //Datatable es un conjunto de datos que estan guardados en tablas y celdas como un excel, por eso este metodo es de tipo datatable, porque los datos los va a guardar en una
        {
            dt.Dispose();
            dt = new DataTable();//Estas dos primeras lineas son muy importantes porque borran la cache de las busquedas anteriores

            MiConsulta = Consulta;
            MiConexion.Open();
            MySqlCommand cmd = new MySqlCommand(MiConsulta, MiConexion); // despues le decimos que comandos debe usar
            MySqlDataAdapter da = new MySqlDataAdapter(cmd); //Y luego le indicamos el adaptador que es la tercera capa y le decimos que coja lo que tenga comand
            da.Fill(dt); //aqui le decimos qque rellene el data table
            MySqlDataReader reader = cmd.ExecuteReader(); // Vamos a la capa comando y le decimos que haga una lectura de lo ultimo que se ha ejecutdado
            //el data reader solo nos sirve para hacer select, solo lee datos, esto hace que sea rapido y consume menos memoria
            //if (reader.HasRows) //Esto dice mientras que reader tenga celdas o filas al lado, avance y entre al if
            //{

            //    reader.Read(); //Nos hace la lectura
            //    //txt_id.Text = reader["idAlmacenes"].ToString();
            //    //txt_nombre.Text = reader["Nombre"].ToString();
            //    //txt_Ubicacion.Text = reader["Ubicacion"].ToString();

            //}
            //else
            //{
            //    Console.WriteLine("No hay datos para mostrar.");
            //}

            reader.Close();
            MiConexion.Close();
            return dt; //Al ser una funcion tipo datatable, debemos devolverle datos tipo datatable
        }

        public BindingSource NavegarRegistros(BindingSource miBindingSource, string accion)
        {
            switch (accion)
            {
                case "avanzar":
                    if (miBindingSource.Position < miBindingSource.Count - 1)
                    {
                        miBindingSource.MoveNext();
                    }
                    break;
                case "retroceder":
                    if (miBindingSource.Position > 0)
                    {
                        miBindingSource.MovePrevious();
                    }
                    break;
                case "inicio":
                    miBindingSource.MoveFirst();
                    break;
                case "fin":
                    miBindingSource.MoveLast();
                    break;

            }

            return miBindingSource;
        }

        public void CrearLabelsYTextBoxes(DataGridView dataGridView, FlowLayoutPanel flowLayoutPanel)
        {
            //Borramos todos los controles del flowlayoutpanel para que cuando cambiemos de tabla solo aparezcan los nuevos
            flowLayoutPanel.Controls.Clear();

            //Le decimos que cree los componentes uno debajo de otro
            flowLayoutPanel.FlowDirection = FlowDirection.TopDown;

            // Crear un label y una textbox por cada columna del DataGridView
            foreach (DataGridViewColumn columna in dataGridView.Columns)
            {
                // Obtener el tipo de datos de la columna
                Type tipoDato = columna.ValueType;

                // Crear un nuevo label con el nombre de la columna
                Label label = new Label();
                label.Name = "lbl_" + columna.Name;
                label.Text = columna.HeaderText + " :";
                label.AutoSize = true;
                label.TextAlign = ContentAlignment.MiddleCenter; // Centrar el texto del label
                label.Margin = new Padding(0, 25, 0, 0);
                flowLayoutPanel.Controls.Add(label);

                // Crear una nueva textbox debajo del label
                TextBox textBox = new TextBox();
                textBox.Name = "txt_" + columna.Name;
                textBox.Margin = new Padding(0, 5, 0, 0); // Establecer un margen de 5 píxeles arriba

                int anchoTextBox = 0;
                int tamañoMaximo = 0;
                // Configurar la entrada de la textbox en función del tipo de datos de la columna
                if (tipoDato == typeof(string))
                {
                    // Si el tipo de datos es string, permitir solo texto
                    textBox.KeyPress += new KeyPressEventHandler(PermitirSoloTexto);

                    // Si el tipo de datos es string, obtener el tamaño máximo de la columna

                    tamañoMaximo = columna.Width;

                    anchoTextBox = tamañoMaximo + 20 ; // Multiplicar por 5 píxeles por letra
                }
                else if (tipoDato == typeof(int))
                {
                    // Si el tipo de datos es int, permitir solo números enteros
                    textBox.KeyPress += new KeyPressEventHandler(PermitirSoloNumerosEnteros);

                    // Si el tipo de datos es int, establecer el ancho de la textbox en función del tamaño del tipo de datos
                    anchoTextBox = sizeof(int) * 10; // Multiplicar por 5 píxeles por byte

                }
                else if (tipoDato == typeof(decimal))
                {
                    // Si el tipo de datos es decimal, permitir solo números decimales
                    textBox.KeyPress += new KeyPressEventHandler(PermitirSoloNumerosDecimales);
                    // Si el tipo de datos es decimal, establecer el ancho de la textbox en función del tamaño del tipo de datos
                    anchoTextBox = sizeof(decimal) * 5; // Multiplicar por 5 píxeles por byte
                }



                textBox.Width = anchoTextBox;
                textBox.AutoSize = true;
                flowLayoutPanel.Controls.Add(textBox);
            }
        }


        /// <summary>
        /// Metodo que solo permite la entrada de texto, por ejemplo en una TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PermitirSoloTexto(object sender, KeyPressEventArgs e)
        {
            // Permitir solo letras y espacios
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Metodo que solo permite la entrada de numeros enteros, por ejemplo en una TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PermitirSoloNumerosEnteros(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números enteros y teclas de control
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Metodo que solo permite la entrada de numeros decimales, por ejemplo en una TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PermitirSoloNumerosDecimales(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números decimales, teclas de control y un solo punto decimal
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != '.' ||
                e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        public DataTable Buscar_Completo(string CadenaBuscar, string tabla, string[] columnas)
        {
            

            string[] CadenaBuena = new string[ArrayLimpiaEspaciosCadena(CadenaBuscar).Length];
            Array.Copy(ArrayLimpiaEspaciosCadena(CadenaBuscar), CadenaBuena, CadenaBuena.Length);
            dt.Clear(); // Primero limpiamos los campos de la tabla para que no se esciban uno tras otro
            if (CadenaBuscar == string.Empty)
            {
                MiConsulta = "SELECT * FROM " + tabla;
            }
            else
            {
                string columnasConcatenadas = string.Join(",", columnas);
                MiConsulta = "SELECT * FROM " + tabla + " Where concat_ws(''," + columnasConcatenadas + ") Like '%" + CadenaBuena[0] + "%'";
                if (CadenaBuena.Count() > 1)
                {
                    for (int i = 1; i < CadenaBuena.Count(); i++)
                    {
                        MiConsulta += " OR concat_ws(''," + columnasConcatenadas + ") Like '%" + CadenaBuena[i] + "%'";
                    }
                }
            }
            Rellenar_Rejilla(MiConsulta);
            EjecutaComando();
            return dt;
        }

        //public string ObtenerNombreTabla(DataGridView dataGridView)
        //{
        //    string nombreTabla = "";
        //    if (dataGridView.DataSource != null && dataGridView.DataSource is DataTable)
        //    {
        //        DataTable dataTable = (DataTable)dataGridView.DataSource;
        //        if (dataTable.ExtendedProperties.ContainsKey("TableMappingName"))
        //        {
        //            nombreTabla = dataTable.ExtendedProperties["TableMappingName"].ToString();
        //        }
        //    }
        //    return nombreTabla;
        //}

        public string[] ObtenerNombresColumnas(DataTable tabla_datos)
        {
            List<string> nombresColumnas = new List<string>();
            foreach (DataColumn columna in tabla_datos.Columns)
            {
                nombresColumnas.Add(columna.ColumnName);
            }
            return nombresColumnas.ToArray();
        }

        /// <summary>
        /// Metodo que busca todas las TextBox existente dentro de un FlowLayoutPanel y vacia su contenido
        /// </summary>
        /// <param name="flowLayoutPanel"></param>
        public void VaciaTextBoxes(FlowLayoutPanel flowLayoutPanel)
        {
            foreach (Control control in flowLayoutPanel.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    textBox.Text = "";
                }
            }
        }

        /// <summary>
        /// Metodo que elimina la fila seleccionada de la tabla de la base de datos gestion_almacen
        /// </summary>
        /// <param name="NombreTabla"></param>
        /// <param name="dataGridView1"></param>
        public void EliminaFilaSeleccionada(string NombreTabla,DataGridView dataGridView1)
        {
            // obtener el índice de la fila seleccionada
            int indiceFilaSeleccionada = dataGridView1.SelectedRows[0].Index;

            // obtener el valor de la celda que contiene la clave primaria de la fila seleccionada
            int valorClavePrimaria = (int)dataGridView1.Rows[indiceFilaSeleccionada].Cells["id"].Value;

            // crear una consulta de eliminación que elimine la fila de la tabla de la base de datos que tenga la clave primaria obtenida anteriormente
            string consultaEliminacion = "DELETE FROM " + NombreTabla + " WHERE id = " + valorClavePrimaria;

            // ejecutar la consulta de eliminación en la base de datos
            using (SqlConnection conexion = new SqlConnection(ConectionStringFunciones))
            {
                SqlCommand comando = new SqlCommand(consultaEliminacion, conexion);
                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }
    }
}
