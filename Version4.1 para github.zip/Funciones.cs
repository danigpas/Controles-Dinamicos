﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SqlClient;
using MySqlX.XDevAPI.Relational;

namespace ControlesDinamicos2._0
{
    internal class Funciones
    {
        #region Variables globales de la clase
        DataTable dt = new DataTable();
        string MiConsulta;
        
        #endregion

        #region Datos Conexion BBDD Funciones
        static string ConectionStringFunciones= "server=localhost;port=3306;uid=root;pwd='';database=gestion_almacen";
        MySqlConnection MiConexion = new MySqlConnection(ConectionStringFunciones);
        MySqlCommand MiCommand = new MySqlCommand();
        #endregion
      

        /// <summary>
        /// Metodo que recibe por parametros un string con lo que se quiere buscar y limpia los espacios que contiene para realizar una busqueda correcta
        /// </summary>
        /// <param name="CadenaBuscar">Todo lo escrito en la TextBox Busqueda</param>
        /// <returns>Devuelve un Array de strings con las palabras que se han introducido como parametros de busqueda limpia sin espacios</returns>
        public string[] ArrayLimpiaEspaciosCadena(string CadenaBuscar)
        {
            string[] palabras = CadenaBuscar.Trim().Split(' '); //Hemos dicho que coja sin espacios por la derecha ni izquierda (el trim) y me divida por espacios y me vaya añadiendo al array

            string[] palabra = new string[palabras.Count()]; //aqui hemos creado otro arrays del tamaño de tantos valores tenga el array
            int contador = 0;
            foreach (string dato in palabras) //Y aqui le hemos dicho que si el valor es un espacio en blanco pase de el y asi tenemos un array solo con los valores reales
            {
                if (dato != "")
                {
                    palabra[contador] = dato;
                    contador++;
                }
            }
            
            //En este punto hemos conseguido un array de strings con exactamente las palabras de la busqueda, ahora ya podemos trabajar con ello

            return palabra;
        }

        /// <summary>
        /// Metodo que limpia los espacios sobrantes de una cadena string recibida por parametros
        /// </summary>
        /// <param name="cadena">La cadena con espacios sobrantes</param>
        /// <returns>Devuelve la cadena limpia de espacios sobrantes</returns>
        public string StringLimpiaEspaciosCadena(string cadena)
        {

            string[] CadenaIntermedia = ArrayLimpiaEspaciosCadena(cadena);
            string CadenaFinal = "";

            foreach (string dato in CadenaIntermedia)
            {
                CadenaFinal = dato + " ";
            }
            return CadenaFinal.Trim(); //Asi devolvemos la cadena sin el espacio al final qe le mete el foreach
        }

        /// <summary>
        /// Metodo que ejecuta los comandos necesarios para realizar una acción sobre la BBDD gestion_almacen
        /// </summary>
        private void EjecutaComando() //Como en todos los metodos estabamos introduciendo estos parametros para conectarnos a la base de datos, creamos un metodo que lo haga una vez y lo llamamos las veces que queramos. Para evitar errores lo hacemos privado para que no pueda cambiar
        {
            MiConexion.Open();
            MiCommand.Connection = MiConexion;
            MiCommand.CommandText = MiConsulta;
            MiCommand.ExecuteNonQuery();
            MiConexion.Close();

            //MiCommand = new MySqlCommand(MiConsulta);


        }

        /// <summary>
        /// Metodo que realiza una consulta SQL recibida por parametros y rellena el datatable con dicha consulta
        /// </summary>
        /// <param name="Consulta">La consulta SQL que se desea realizar</param>
        /// <returns>Devuelve un datatable ya rellenado tras realizar la consulta</returns>
        public DataTable Rellenar_Rejilla(string Consulta) //Datatable es un conjunto de datos que estan guardados en tablas y celdas como un excel, por eso este metodo es de tipo datatable, porque los datos los va a guardar en una
        {
            dt.Dispose();
            dt = new DataTable();//Estas dos primeras lineas son muy importantes porque borran la cache de las busquedas anteriores

            MiConsulta = Consulta;
            MiConexion.Open();
            MySqlCommand cmd = new MySqlCommand(MiConsulta, MiConexion); // despues le decimos que comandos debe usar
            MySqlDataAdapter da = new MySqlDataAdapter(cmd); //Y luego le indicamos el adaptador que es la tercera capa y le decimos que coja lo que tenga comand
            da.Fill(dt); //aqui le decimos qque rellene el data table
            MySqlDataReader reader = cmd.ExecuteReader(); // Vamos a la capa comando y le decimos que haga una lectura de lo ultimo que se ha ejecutdado
            //el data reader solo nos sirve para hacer select, solo lee datos, esto hace que sea rapido y consume menos memoria
            
            reader.Close();
            MiConexion.Close();
            return dt; //Al ser una funcion tipo datatable, debemos devolverle datos tipo datatable
        }

        /// <summary>
        /// Metodo que nos permite navegar dentro de nuestras tablas aprovechando los metodos nativos de un BindingSource
        /// </summary>
        /// <param name="miBindingSource">BindingSource del DatagridView sobre el que queremos navegar</param>
        /// <param name="accion">Accion que queremos realizar dentro de dicho datagridview</param>
        /// <returns>Devuelve un bindingsource con la accion de navegacion ya realizada</returns>
        public BindingSource NavegarRegistros(BindingSource miBindingSource, string accion)
        {
            switch (accion)
            {
                case "avanzar":
                    if (miBindingSource.Position < miBindingSource.Count - 1)
                    {
                        miBindingSource.MoveNext();
                    }
                    break;
                case "retroceder":
                    if (miBindingSource.Position > 0)
                    {
                        miBindingSource.MovePrevious();
                    }
                    break;
                case "inicio":
                    miBindingSource.MoveFirst();
                    break;
                case "fin":
                    miBindingSource.MoveLast();
                    break;

            }

            return miBindingSource;
        }


        /// <summary>
        /// Metodo que lee las columnas de una tabla y crea de forma dinamica un label con su respectivo TextBox de cada columna de forma dinamica
        /// </summary>
        /// <param name="dataGridView">Datagridview del que se van a leer todas las columnas</param>
        /// <param name="flowLayoutPanel">Contenedor al que se van a añadir todos los objetos creados de forma dinamica</param>
        public void CrearLabelsYTextBoxes(DataGridView dataGridView, FlowLayoutPanel flowLayoutPanel)
        {
            //Borramos todos los controles del flowlayoutpanel para que cuando cambiemos de tabla solo aparezcan los nuevos
            flowLayoutPanel.Controls.Clear();

            //Le decimos que cree los componentes uno debajo de otro
            flowLayoutPanel.FlowDirection = FlowDirection.TopDown;

            // Crear un label y una textbox por cada columna del DataGridView
            foreach (DataGridViewColumn columna in dataGridView.Columns)
            {
                // Obtener el tipo de datos de la columna
                Type tipoDato = columna.ValueType;

                // Crear un nuevo label con el nombre de la columna
                Label label = new Label();
                label.Name = "lbl_" + columna.Name;
                label.Text = columna.HeaderText + " :";
                label.AutoSize = true;
                label.TextAlign = ContentAlignment.MiddleCenter; // Centrar el texto del label
                label.Margin = new Padding(0, 25, 0, 0);
                flowLayoutPanel.Controls.Add(label);

                // Crear una nueva textbox debajo del label
                TextBox textBox = new TextBox();
                textBox.Name = "txt_" + columna.Name;
                textBox.Margin = new Padding(0, 5, 0, 0); // Establecer un margen de 5 píxeles arriba

                int anchoTextBox = 0;
                int tamañoMaximo = 0;
                // Configurar la entrada de la textbox en función del tipo de datos de la columna
                if (tipoDato == typeof(string))
                {
                    // Si el tipo de datos es string, permitir solo texto
                    //textBox.KeyPress += new KeyPressEventHandler(PermitirSoloTexto);

                    // Si el tipo de datos es string, obtener el tamaño máximo de la columna

                    tamañoMaximo = columna.Width;

                    anchoTextBox = tamañoMaximo + 20 ; // Multiplicar por 5 píxeles por letra
                }
                else if (tipoDato == typeof(int))
                {
                    // Si el tipo de datos es int, permitir solo números enteros
                    //textBox.KeyPress += new KeyPressEventHandler(PermitirSoloNumerosEnteros);

                    // Si el tipo de datos es int, establecer el ancho de la textbox en función del tamaño del tipo de datos
                    anchoTextBox = sizeof(int) * 10; // Multiplicar por 5 píxeles por byte

                }
                else if (tipoDato == typeof(decimal))
                {
                    // Si el tipo de datos es decimal, permitir solo números decimales
                    //textBox.KeyPress += new KeyPressEventHandler(PermitirSoloNumerosDecimales);
                    // Si el tipo de datos es decimal, establecer el ancho de la textbox en función del tamaño del tipo de datos
                    anchoTextBox = sizeof(decimal) * 5; // Multiplicar por 5 píxeles por byte
                }



                textBox.Width = anchoTextBox;
                textBox.AutoSize = true;
                flowLayoutPanel.Controls.Add(textBox);
            }
        }


        /// <summary>
        /// Metodo que solo permite la entrada de texto, por ejemplo en una TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PermitirSoloTexto(object sender, KeyPressEventArgs e)
        {
            // Permitir solo letras y espacios
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Metodo que solo permite la entrada de numeros enteros, por ejemplo en una TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PermitirSoloNumerosEnteros(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números enteros y teclas de control
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Metodo que solo permite la entrada de numeros decimales, por ejemplo en una TextBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PermitirSoloNumerosDecimales(object sender, KeyPressEventArgs e)
        {
            // Permitir solo números decimales, teclas de control y un solo punto decimal
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != '.' ||
                e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Metodo que realiza la busqueda con unos parametros de entrada dentro de la tabla abierta en la Pestaña Datos
        /// </summary>
        /// <param name="CadenaBuscar">Texto que quiere buscar el usuario</param>
        /// <param name="tabla">Tabla en la que lo quiere buscar</param>
        /// <param name="columnas">Nombre de las columans de la tabla donde se va a realizar la busqueda</param>
        /// <returns>Devuelve un datatable rellenado con el resultado de la busqueda realizada</returns>
        public DataTable Buscar_Completo(string CadenaBuscar, string tabla, string[] columnas, BindingSource miBindingSource)
        {
           
            

            string[] CadenaBuena = new string[ArrayLimpiaEspaciosCadena(CadenaBuscar).Length];
            Array.Copy(ArrayLimpiaEspaciosCadena(CadenaBuscar), CadenaBuena, CadenaBuena.Length);
            dt.Clear(); // Primero limpiamos los campos de la tabla para que no se esciban uno tras otro
            if (CadenaBuscar == string.Empty)
            {
                miBindingSource.Filter = null;  
                //MiConsulta = "SELECT * FROM " + tabla;
                dt = BusquedaVacia(tabla, dt);
               
                //miBindingSource.DataSource = dt;
            }
            else 
            {
                int id_def_tabla = Devuelve_id_def_tablas(tabla);
                string[]ColumnasOriginal= ObtenerNombresColumnasOriginal(id_def_tabla);

                //Ahora vamos a crear un array para setear las cabeceras de la busqueda
                string CabeceraSeteada = "";
                CabeceraSeteada = CreaCabecerasBusqueda(ColumnasOriginal, columnas);

                string columnasConcatenadas = string.Join(",", ColumnasOriginal);
                MiConsulta = "SELECT " + CabeceraSeteada +" FROM " + tabla + " Where concat_ws(''," + columnasConcatenadas + ") Like '%" + CadenaBuena[0] + "%'";
                if (CadenaBuena.Count() > 1)
                {
                    for (int i = 1; i < CadenaBuena.Count(); i++)
                    {
                        MiConsulta += " OR concat_ws(''," + columnasConcatenadas + ") Like '%" + CadenaBuena[i] + "%'";
                    }
                }
                dt = Rellenar_Rejilla(MiConsulta);
                EjecutaComando();

            }
            
            return dt;
        }

        /// <summary>
        /// Metodo que une el nombre original de la cabecera con su nombre para mostrar recogido en def_campos
        /// </summary>
        /// <param name="columnasOriginal">Array de todos los nombres originales de la tabla</param>
        /// <param name="columnasDeseadas">Array de todos los nombres a mostrar de la tabla</param>
        /// <returns>Devuelve el string ya seteado</returns>
        public string CreaCabecerasBusqueda(string[] columnasOriginal, string[] columnasDeseadas)
        {
            
            StringBuilder stringBuilder = new StringBuilder();

            for (int i = 0; i < columnasOriginal.Length; i++)
            {
                stringBuilder.Append(columnasOriginal[i]);
                stringBuilder.Append(" AS \"");
                stringBuilder.Append(columnasDeseadas[i]);
                stringBuilder.Append("\"");

                if (i < columnasOriginal.Length - 1)
                {
                    stringBuilder.Append(", ");
                }
            }

             string columnaString = stringBuilder.ToString();
            return columnaString;
        }

       
        /// <summary>
        /// Metodo que obtiene el nombre de todas las columnas de una tabla y lo guarda en un array
        /// </summary>
        /// <param name="tabla_datos">DataTable de la tabla de la que se quieren obtener las columnas</param>
        /// <returns>Devuelve un array que contiene el nombre de todas las columnas</returns>
        public string[] ObtenerNombresColumnasOriginal(int id)
        {
            
            List<string> campos = new List<string>();

            using (MySqlConnection connection = new MySqlConnection(ConectionStringFunciones))
            {
                connection.Open();

                string sql = "SELECT Nombre_Campo FROM gestion_almacen.def_campos WHERE idDef_Tablas = " +id ;

                using (MySqlCommand command = new MySqlCommand(sql, connection))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string campo = reader.GetString(0);
                            campos.Add(campo);
                        }
                    }
                }
            }

            return campos.ToArray();
        }

        /// <summary>
        /// Metodo que obtiene el nombre de todas las columnas de una tabla y lo guarda en un array
        /// </summary>
        /// <param name="tabla_datos">DataTable de la tabla de la que se quieren obtener las columnas</param>
        /// <returns>Devuelve un array que contiene el nombre de todas las columnas</returns>
        public string[] ObtenerNombresColumnasMostradas(int id)
        {
            

            List<string> campos = new List<string>();

            using (MySqlConnection connection = new MySqlConnection(ConectionStringFunciones))
            {
                connection.Open();

                string sql = "SELECT Nombre_para_Mostrar FROM gestion_almacen.def_campos WHERE idDef_Tablas = " + id;

                using (MySqlCommand command = new MySqlCommand(sql, connection))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string campo = reader.GetString(0);
                            campos.Add(campo);
                        }
                    }
                }
            }

            return campos.ToArray();
        }

        /// <summary>
        /// Metodo que busca todas las TextBox existente dentro de un FlowLayoutPanel y vacia su contenido
        /// </summary>
        /// <param name="flowLayoutPanel">Contenedor del que se quieren vaciar las cajas de texto</param>
        public void VaciaTextBoxes(FlowLayoutPanel flowLayoutPanel)
        {
            foreach (Control control in flowLayoutPanel.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    textBox.Text = "";
                }
            }
        }

        /// <summary>
        /// Metodo que elimina la fila seleccionada de la tabla de la base de datos gestion_almacen
        /// </summary>
        /// <param name="NombreTabla">Nombre de la tabla donde se quiere hacer el delete</param>
        /// <param name="nombreid">Nombre de la columna id de la tabla</param>
        /// <param name="Valorid">Valor del campo id del que se va a hacer el delete</param>
        public void EliminaFilaSeleccionada(string NombreTabla, string nombreid, int Valorid)
        {
           
            // crear una consulta de eliminación que elimine la fila de la tabla de la base de datos que tenga la clave primaria obtenida anteriormente
            string consultaEliminacion = "DELETE FROM " + NombreTabla + " WHERE "+ nombreid + " = " + Valorid;

            // ejecutar la consulta de eliminación en la base de datos
            using (MySqlConnection conexion = new MySqlConnection(ConectionStringFunciones))
            {
                MySqlCommand comando = new MySqlCommand(consultaEliminacion, conexion);
                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }


        /// <summary>
        /// Metodo que inserta una fila en la tabla abierta en la pestaña Datos
        /// </summary>
        /// <param name="NombreColumnas">Nombre de la columnas de la tabla abierta</param>
        /// <param name="tabla">Nombre de la tabla que se esta mostrando</param>
        /// <param name="ValoresTextBox">Contenido con el que se quiere insertar la nueva fila en la tabla</param>
        public void InsertaFila(string[]NombreColumnas, string tabla, string[]ValoresTextBox)
        {
            string columnasConcatenadas = string.Join(",", NombreColumnas);

            NombreColumnas[0] = "@" + NombreColumnas[0];
            string columnasvalores= string.Join(",@", NombreColumnas);


            MiConsulta = "INSERT INTO " + tabla + " ( " + columnasConcatenadas + " ) VALUES ( " + columnasvalores  + " );";

            int contador = 0;
            foreach (string nombre in ValoresTextBox)
            {
                MiCommand.Parameters.AddWithValue(NombreColumnas[contador], ValoresTextBox[contador]);
                contador++;
            }

            EjecutaComando();

        }


        /// <summary>
        /// Metodo que actualiza los campos de una fila de la tabla abierta en la pestaña Datos
        /// </summary>
        /// <param name="NombreColumnas">Nombre de las columnas de la tabla abierta</param>
        /// <param name="tabla">Nombre de la tabla abierta</param>
        /// <param name="ValoresTextBox">Valores con los que se van a actualizar los campos</param>
        /// <param name="id">Valor del campo id que se va a actualizar</param>
        /// <param name="NombreId">Nombre de la columna id de la tabla abierta</param>
        public void ActualizaFila(string[] NombreColumnas, string tabla, string[] ValoresTextBox, int id, string NombreId)
        {
            string columnasConcatenadas = string.Join(",", NombreColumnas);

            
            string[] NombreColumnasSucio = new string[NombreColumnas.Length];
            Array.Copy(NombreColumnas,NombreColumnasSucio,NombreColumnas.Length);


            NombreColumnasSucio[0] = "@" + NombreColumnasSucio[0];
            string columnasvalores = string.Join(",@", NombreColumnasSucio);
            string[] ColumnasArroba = columnasvalores.Split(',');
            
                int contador3 = 0;
            MiConsulta = "UPDATE " + tabla + " SET ";
            string MiConsultaSecundaria = "";
            foreach (string nombre in ValoresTextBox)
            {
                
                MiConsultaSecundaria +=  NombreColumnas[contador3] + " = " + ColumnasArroba[contador3] + " , ";
                contador3++;
            }

            // Eliminar la última coma de la cadena
            char[] charsToTrim = { ',' , ' ' }; //Ahora debemos de borrar la ultima coma y el espacio de despues
            MiConsultaSecundaria = MiConsultaSecundaria.TrimEnd(charsToTrim);

            MiConsulta = MiConsulta + MiConsultaSecundaria+" WHERE " + NombreId + " = " + id;

            int contador2 = 0;
            foreach (string nombre in ValoresTextBox)
            {
                MiCommand.Parameters.AddWithValue(NombreColumnas[contador2], ValoresTextBox[contador2]);
                contador2++;
            }
            EjecutaComando();

        }

        /// <summary>
        /// Metodo que devuelve el valor entero id_def_tabla de la tabla deseada
        /// </summary>
        /// <param name="tabla">nombre de la tabla que se desea conocer su id</param>
        /// <returns>devuelve un int con el valor id_def_tabla de dicha tabla</returns>
        public int Devuelve_id_def_tablas(string tabla)
        {
            switch(tabla)
            {
                case "almacenes" :
                    return 1;
                    break;

                case "articulos":
                    return 2;
                    break;

                case "clientes":
                    return 3;
                    break;

                case "estanterias":
                    return 4;
                    break;

                case "stock":
                    return 5;
                    break;

                case "ubicacion_articulo":
                    return 6;
                    break;

                
            }
            return 7; //Este es el caso que sea la tabla mensajeria
        }

        /// <summary>
        /// Metodo que realiza todo lo necesario para hacer una busqueda sin parametros de busqueda o vacia
        /// </summary>
        /// <param name="nombre_campo">Nombre de la tabla en la que se busca</param>
        /// <param name="dt_Tabla">Datatable que se esta mostrando</param>
        /// <returns>devuelve un datatable con el resultado de la busqueda</returns>
        public DataTable BusquedaVacia(string nombre_campo,DataTable dt_Tabla)
        {


            int id_def_tabla = Devuelve_id_def_tablas(nombre_campo);

            dt_Tabla.Dispose();
            DataTable data = new DataTable();
            using (MySqlConnection connection = new MySqlConnection(ConectionStringFunciones))
            {
                // Abrir la conexión
                connection.Open();
                string sql = "SELECT obtener_consulta(@tabla, @id_def_tabla)";

                using (MySqlCommand command = new MySqlCommand(sql, connection))
                {
                    // Pasar los parámetros a la función
                    command.Parameters.AddWithValue("@tabla", nombre_campo);
                    command.Parameters.AddWithValue("@id_def_tabla", id_def_tabla);

                    // Ejecutar la consulta y obtener el resultado
                    string consulta = command.ExecuteScalar().ToString();

                    // Crear un nuevo comando con la consulta obtenida
                    using (MySqlCommand consultaCommand = new MySqlCommand(consulta, connection))
                    {
                        // Crear un adaptador de datos y un DataTable
                        MySqlDataAdapter adapter = new MySqlDataAdapter(consultaCommand);


                        // Rellenar el DataTable con el resultado de la consulta
                        adapter.Fill(data);
                    }
                }
            }

            return data;


        }

    }
}
