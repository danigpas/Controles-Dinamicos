﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Proyecto Controles Dinámicos
//Creación 20/04/2023
//Autor: Daniel González Pascual
//Últimas modificaciónes:
//          20/04/2023 19:19 -> Grabación de etiquetas en la clase
//              He grabado el primer método y le he añadido el campo que faltaba -> Dani
//          **********************************************************************
//          01/05/2023 16:00 -> Versión 1.0
//              Se ha creado una primera versión del proyecto funcional que trabaja solo con la tabla almacenes-> Dani
//          **********************************************************************
//          12/05/2023 16:00 -> Versión 2.0
//              Se ha implementado una segunda versión del proyecto que ya es capaz de mostrar de forma dinámica todas las tablas del proyecto -> Dani
//          *****************************************************************************
//          30/05/2023 12:00  -> Versión 3.0
//              Se ha implementado una tercera versión del proyecto que ya es capaz de realizar cualquier modificación CRUD en todas las tablas , además se
//              ha implementado un método de busqueda para la tabla que tengamos abierta. En definitiva se pueden usar todos los controles del proyecto. -> Dani
//          ********************************************************************************
//          02/06/2023 12:00 -> Versión 4.0
//              Se ha implementado el nuevo menu con imagenes personalizadas y botones. Además se han arreglado todas las funcionalidades del proyecto para que funcionen
//              con las nuevas tablas (recordar que ahora la cabecera es nombre_para_mostrar de la tabla def_campos). -> Dani   
//          **********************************************************************************
//          06/06/2023 11:33 -> Versión 4.1
//              Se ha implementado un login que compara el nombre de usuario y el codigo hash256 de la contraseña con sus respectivos parametreos de la bbdd user_almacen.
//              Además se ha implementado un menu para que el usuario elija quien esta manejando el ordenador antes de logearse y así al abrirse el programa guarda y muestra
//              tanto el perfil de windows que lo está usando como la persona (de momento se muestran en la cabecera del programa). Por último en el apartado de diseño se ha
//              implementado una pantalla de carga entre la ventana del login y la del programa -> Dani


namespace ControlesDinamicos2._0
{
    public partial class Form1 : Form
    {
        
        /// <summary>
        /// Metodo constructor de la clase Form1
        /// </summary>
        /// <param name="que"></param>
        public Form1()
        {
           
            InitializeComponent();
            

        }
            
        

        /// <summary>
        /// Metodo que concentra todo lo que tiene que hacer esta clase, para evitar un error anterior de que se abriesen las clases en bucle infinito unas a otras
        /// </summary>
        public void EvitaBucles() //Para evitar que se creen bucles infinitos cuando se llama a la clase form con las instancias de las otras clases, vamos a abstraerlo todo en este metodo
            {
            
            
                Flujo flujo = new Flujo();
                PestañaMenu menu = new PestañaMenu();

                flujo.FlujoPrograma(this);
                menu.ConfiguraMenu(this);
            
            }

       
      
        /// <summary>
        /// Evento que se ejecuta cuando se muestra la ventana del form1 , es util para cambiar sus propiedades como el nombre, iconos, etc.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Shown(object sender, EventArgs e)
        {
            string userProfile = Environment.GetEnvironmentVariable("USERPROFILE");
            string userName = System.IO.Path.GetFileName(userProfile);
            //Vamos a cambiar el texto de la ventana
            LoginForm login = new LoginForm();
            string usuario = login.GetSeleccionComboBox().ToString();
            this.Text = userName + " - " + usuario ;
            

            // Cargar el icono desde un archivo
            Icon icon = new Icon("C:\\Users\\danig\\OneDrive\\Escritorio\\curso\\IMG\\logo_app.ico");

            // Establecer el icono de la ventana
            this.Icon = icon;

            EvitaBucles();
        }
        
        /// <summary>
        /// Evento del Form1 que se ejecuta cuando se está cerrando la ventana, en este caso lo usamos con el object Application para cerrar la aplicación.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}

