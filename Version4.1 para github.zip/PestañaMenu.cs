﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography.X509Certificates;
using Org.BouncyCastle.Asn1.Crmf;

namespace ControlesDinamicos2._0
{
    internal class PestañaMenu
    {
        #region Datos dg_Menu
        DataGridView dg_Menu;
        string Nombre_dg_Menu = "dg_Menu";
        Point localizacion_dg_Menu = new Point(1, 1);
        Size tamaño_dg_Menu = new Size(200, 200);
        #endregion

        #region Variables globales de la clase PestañaMenu
        Controles controles = new Controles();
        Flujo claseflujo = new Flujo();

        DataTable dt = new DataTable();
        TabControl tabControl;
        Form1 MiFormulario = new Form1();
        
        
        #endregion

        #region Datos Conexion a la BBDD
        static string StringConexionMenu = "server=localhost;port=3306;uid=root;pwd='';database=gestion_almacen";
        MySqlConnection ConexionMenu = new MySqlConnection(StringConexionMenu);
        #endregion

        /// <summary>
        /// Metodo que construye el flujo que va a tener esta clase para que guie al Form1
        /// </summary>
        /// <param name="form">Form1 que va a seguir el flujo de la clase</param>
        public void ConfiguraMenu(Form1 form)
        {
            //Vamos a buscar el tabcontrol y la pestaña menu para trabajar con ellas
             Control miComponente = form.Controls["tb_Principal"];
             tabControl = (TabControl)miComponente;

            Control miComponente2 = tabControl.TabPages["tbpage_Menu"];
            TabPage PestañaMenu = (TabPage)miComponente2;

            MuestraMenu(PestañaMenu);
        }

        /// <summary>
        /// Metodo que muestra una consulta con todas sql con todas las tablas de la BBDD gestion_almacen y lo asigna a un datagridview
        /// </summary>
        /// <param name="data">Datagridview que va a mostrar la consulta</param>
        public void MuestraMenu(DataGridView data)
        {

            dt.Clear();
            //dt.Reset();
            ConexionMenu.Open();

            //string consulta = "show tables from gestion_almacen"; hemos encontrado una mejor consulta
            string consulta = "SELECT table_name AS nombre " +
                "FROM information_schema.tables " +
                "WHERE table_schema = 'gestion_almacen' " +
                "AND table_name <> 'ubicacion_articulo' " +
                "AND table_name <> 'def_tablas' "+
                "AND table_name <> 'def_campos' "+
                "AND TABLE_TYPE <> 'VIEW' ;";

            MySqlCommand cmd = new MySqlCommand(consulta, ConexionMenu);
            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);

            adapter.Fill(dt);
            data.DataSource = dt;
            data.AutoResizeColumns();

            ConexionMenu.Close();


        }

        /// <summary>
        /// Metodo que configura todos los controles de la `pestaña Menu (en esta versión son botones no celdas)
        /// </summary>
        /// <param name="menu">Pestaña a la que se añaden todos los controles</param>
        public void MuestraMenu(TabPage menu) {
            // Obtener los registros de la tabla def_tablas
            DataTable tabla = GetDefTablas();

            // Coordenadas iniciales para la posición de los botones y etiquetas
            int x = 10;
            int y = 10;

            FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel();
            flowLayoutPanel.Dock = DockStyle.Fill;
            flowLayoutPanel.FlowDirection = FlowDirection.LeftToRight;

            menu.Controls.Add(flowLayoutPanel);
            // Crear botones y etiquetas para cada fila de la tabla
            foreach (DataRow row in tabla.Rows)
            {
                // Obtener los valores de cada columna de la fila
                int idDefTablas = Convert.ToInt32(row["idDef_Tablas"]);
                string nombreTabla = row["Nombre_Tabla"].ToString();
                string nombreParaMostrar = row["Nombre_Para_Mostrar"].ToString();
                int orden = Convert.ToInt32(row["orden"]);
                string imagen = row["imagen"].ToString();

                // Crear un nuevo botón
                Button button = new Button();
                button.Text = nombreParaMostrar;
                button.Name = nombreTabla;
                button.Location = new Point(x, y);
                button.Size = new Size(200, 100);
                button.Click += new EventHandler(button_Click);

                // Cargar la imagen para el botón
                button.Image = Image.FromFile(imagen);
                button.ImageAlign = ContentAlignment.TopCenter;
                button.TextImageRelation = TextImageRelation.ImageAboveText;

               


                // Agregar el botón al formulario
                
                flowLayoutPanel.Controls.Add(button);

                
                // Actualizar las coordenadas para la próxima posición
                x += 120;
                if (x > menu.Width - 120)
                {
                    x = 10;
                    y += 100;
                }
            }
        }

        /// <summary>
        /// Evento que se dispara cuando se pulsa un boton del menu y que se usa para mostrar la tabla seleccionada
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Click (object sender, EventArgs e)
        {
            // Guarda el valor de la celda en un string
            

            Button button = (Button)sender;
            

            string nombreTabla = button.Name;
            claseflujo.AbreTablaGestion_Almacen(nombreTabla, tabControl);
        }

        /// <summary>
        /// Metodo que muestra todos los campos de la tabla def_tablas
        /// </summary>
        /// <returns>Devuelve un datatable con la consulta rellenada</returns>
        private DataTable GetDefTablas()
        {
            DataTable tabla = new DataTable();

            using (MySqlConnection connection = new MySqlConnection(StringConexionMenu))
            {
                connection.Open();

                string sql = "SELECT idDef_Tablas, Nombre_Tabla, Nombre_Para_Mostrar, orden, imagen FROM def_tablas";

                using (MySqlCommand command = new MySqlCommand(sql, connection))
                {
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        adapter.Fill(tabla);
                    }
                }
            }

            return tabla;
        }




    }
}
