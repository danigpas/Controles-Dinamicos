﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;
using System.DirectoryServices.AccountManagement;



namespace ControlesDinamicos2._0
{

    public partial class LoginForm : Form
    {
        #region Variables de la Clase LoginForm
        string username = "";
        string password = "";

        string connectionString = "server=localhost;port=3306;uid=root;pwd='';database=users_almacen";

        string storedPassword = null;
        TextBox txtUsuario = new TextBox();
        TextBox txtContraseña = new TextBox();
        static ComboBox comboBox;
        string seleccion;
        #endregion

        /// <summary>
        /// Constructor de la clase loginform
        /// </summary>
        public LoginForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Metodo que configura y crea todos los controles que muestra la ventana del login
        /// </summary>
        public void CreaLogin()
        {
            var lblUsername = new Label()
            {
                Text = "Nombre de usuario:",
                Location = new Point(50, 50),
                Size = new Size(200, 30),
                ForeColor = Color.FromArgb(44, 62, 80)

            };

            var lblPassword = new Label()
            {
                Text = "Contraseña:",
                Location = new Point(50, 150),
                Size = new Size(200, 30),
                ForeColor = Color.FromArgb(44, 62, 80)
            };

            var btnLogin = new Button()
            {
                Text = "Iniciar sesión",
                Location = new Point(100, 250),
                Size = new Size(100, 30),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(52, 152, 219)
            };
            btnLogin.Click += BtnLogin_Click;



            txtUsuario.Location = new Point(50, 90);
            txtUsuario.Size = new Size(200, 30);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.BorderStyle = BorderStyle.Fixed3D;
            txtUsuario.BackColor = Color.FromArgb(236, 240, 241);
            txtUsuario.ForeColor = Color.FromArgb(44, 62, 80);
            txtUsuario.Font = new Font("Segoe UI", 12f, FontStyle.Regular);





            txtContraseña.Location = new Point(50, 170);
            txtContraseña.Size = new Size(200, 30);
            txtContraseña.PasswordChar = '*';
            txtContraseña.Name = "txtPassword";
            txtContraseña.BorderStyle = BorderStyle.Fixed3D;
            txtContraseña.BackColor = Color.FromArgb(236, 240, 241);
            txtContraseña.ForeColor = Color.FromArgb(44, 62, 80);
            txtContraseña.Font = new Font("Segoe UI", 12f, FontStyle.Regular);



            this.Controls.Add(lblUsername);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtUsuario);
            this.Controls.Add(txtContraseña);
            this.Controls.Add(btnLogin);
        }

        /// <summary>
        /// Evento que se lanza cuando se está cargando la ventana del login LoginForm, edita las dimensiones de dicha ventana
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Establecer el tamaño y estilo del formulario
            this.Text = "Iniciar Sesión";
            this.Size = new Size(330, 400);
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            //this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;

            CreaLogin();
            CreateDropDownMenu();

        }

        /// <summary>
        /// Evento que se lanza cuando se pulsa click en el btn_login
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            //loginSuccessful = true;
            Label lbl_Error = new Label();
            lbl_Error.Name = "lbl_Error";
            lbl_Error.Location = new Point(50, 210);
            lbl_Error.Text = "";
            lbl_Error.Size = new Size(150, 20);
            lbl_Error.ForeColor = Color.Red;
            if (LoginCorrecto() == true)
            {
                this.Hide();
                PantallaCarga Carga = new PantallaCarga();
                Carga.Show();
            }
            else
            {
                lbl_Error.Text = "Usuario u Contraseña incorrectos ";
                this.Controls.Add(lbl_Error);


            }
            
        }

        /// <summary>
        /// Metodo que crea un menu en la ventana del login para seleccionar que persona va a acceder al programa
        /// </summary>
        public void CreateDropDownMenu()
        {
            // Crear un ComboBox y agregar nombres de ejemplo
            comboBox = new ComboBox();
            comboBox.Items.AddRange(new string[] { "Kiko", "Dani", "Antonio" });

            // Configurar la posición y el tamaño del ComboBox
            comboBox.Left = 10;
            comboBox.Top = 10;
            comboBox.Width = 150;

            // Agregar un controlador de eventos para capturar la selección
            comboBox.SelectedIndexChanged += ComboBox_SelectedIndexChanged;

            // Agregar el ComboBox al formulario
            Controls.Add(comboBox);
        }

        /// <summary>
        /// Evento que guarda la selección del usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Guardar la selección en una variable
            seleccion = comboBox.SelectedItem.ToString();

            //// Hacer algo con la selección (por ejemplo, mostrarla en una ventana emergente)
            //MessageBox.Show("Selección: " + seleccion);
        }

        /// <summary>
        /// Metodo get que devuelve el valor en string de la seleccion del usuario en la ComboBox de login
        /// </summary>
        /// <returns>Devuelve un string con la selección</returns>
        public string GetSeleccionComboBox()
        {
            seleccion = comboBox.SelectedItem.ToString();
            return seleccion;
        }

        /// <summary>
        /// Metodo que compara los parametros introducidos por el usuario como nombre y contraseña con los guardados en la bbdd users_almacen para ver si encuentra coincidencia,
        /// en caso de ser true le concede acceso, en caso contrario muestra un mensaje de error para que corrija los datos
        /// </summary>
        /// <returns>Devuelve un booleano con el resultado del login (true o false)</returns>
        private bool LoginCorrecto()
        {
            username = txtUsuario.Text;
            password = txtContraseña.Text;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT Contraseña FROM usuarios WHERE N_Usuario = @username";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            storedPassword = reader.GetString("Contraseña");
                        }
                    }
                }
            }
            string hashedPassword;

            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();

                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }

                hashedPassword = builder.ToString();
            }

            bool isPasswordCorrect = (hashedPassword == storedPassword);
            return isPasswordCorrect;
        }

        /// <summary>
        /// Metodo que compara las credenciales de windows con el texto introducido en el login 
        /// </summary>
        /// <returns>Devuelve si la comprobación ha sido correcta o incorrecta</returns>
        private bool LoginWindows()
        {
            string enteredPassword = txtContraseña.Text; // Valor ingresado por el usuario en el TextBox
            string enteredUser = txtUsuario.Text;
            bool logincorrecto = false;
            try
            {
                using (PrincipalContext context = new PrincipalContext(ContextType.Machine))
                {
                    // Verificar si el nombre de usuario y la contraseña ingresados coinciden con los del perfil de Windows
                    bool isCredentialsCorrect = context.ValidateCredentials(enteredUser, enteredPassword);//TODO: revisar porque las credenciales no se comparan bien

                    if (isCredentialsCorrect)
                    {
                        logincorrecto = true;
                    }
                    else
                    {
                        logincorrecto = false;
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                MessageBox.Show("Error en el manejo del usuario de windows");
            }
            return logincorrecto;
        }
    }
}
