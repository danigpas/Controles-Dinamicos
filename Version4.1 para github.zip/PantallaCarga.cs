﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlesDinamicos2._0
{
    public partial class PantallaCarga : Form
    {

        /// <summary>
        /// Metodo constructor de la clase PantallaCarga
        /// </summary>
        public PantallaCarga()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Evento que se dispara con cada tick del timer y que aprovechamos para que se incremente la barra de progreso
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Increment(1);
            lbl_porcentaje.Text = progressBar1.Value.ToString() + "%";

            if (progressBar1.Value == 25 )
            {
                lbl_datosCarga.Text = "Arrancando los servidores . . .";
            }
            else if (progressBar1.Value == 50)
            {
                lbl_datosCarga.Text = "Abriendo los almacenes . . .";
            }
            else if (progressBar1.Value == 75)
            {
                lbl_datosCarga.Text = "Despertando al personal . . .";
            }
            else if (progressBar1.Value == 98)
            {
                lbl_datosCarga.Text = "¡Bienvenido!";
            }
            else if (progressBar1.Value == progressBar1.Maximum )
            {
                timer1.Stop();
                this.Hide();
                Form1 Ventana = new Form1();


                Ventana.Show();
            }
        }
    }
}
