﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlesDinamicos2._0
{
    public partial class Form1 : Form
    {
        
        public Form1(bool que)
        {
            if (que)
            {
            InitializeComponent();
            
            EvitaBucles();
            }
        }
        /// <summary>
        /// Metodo que concentra todo lo que tiene que hacer esta clase, para evitar un error anterior de que se abriesen las clases en bucle infinito unas a otras
        /// </summary>
        public void EvitaBucles() //Para evitar que se creen bucles infinitos cuando se llama a la clase form con las instancias de las otras clases, vamos a abstraerlo todo en este metodo
        {
            
            Flujo flujo = new Flujo();
            PestañaMenu menu = new PestañaMenu();

            flujo.FlujoPrograma(this);
            menu.ConfiguraMenu(this);
            
        }
      
        /// <summary>
        /// Evento que se ejecuta cuando se muestra la ventana del form1 , es util para cambiar sus propiedades como el nombre, iconos, etc.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Shown(object sender, EventArgs e)
        {
            //Vamos a cambiar el texto de la ventana
            this.Text = "Dinamico";

            // Cargar el icono desde un archivo
            Icon icon = new Icon("C:\\Users\\danig\\OneDrive\\Escritorio\\curso\\IMG\\logo_app.ico");

            // Establecer el icono de la ventana
            this.Icon = icon;
        }
    }
}
