﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography.X509Certificates;

namespace ControlesDinamicos2._0
{
    internal class PestañaMenu
    {
        #region Datos dg_Menu
        DataGridView dg_Menu;
        string Nombre_dg_Menu = "dg_Menu";
        Point localizacion_dg_Menu = new Point(1, 1);
        Size tamaño_dg_Menu = new Size(200, 200);
        #endregion

        #region Variables globales de la clase PestañaMenu
        Controles controles = new Controles();
        Flujo claseflujo = new Flujo();

        DataTable dt = new DataTable();
        TabControl tabControl;
        Form1 MiFormulario = new Form1(false);
        #endregion

        #region Datos Conexion a la BBDD
        static string StringConexionMenu = "server=localhost;port=3306;uid=root;pwd='';database=gestion_almacen";
        MySqlConnection ConexionMenu = new MySqlConnection(StringConexionMenu);
        #endregion

        /// <summary>
        /// Metodo que construye el flujo que va a tener esta clase para que guie al Form1
        /// </summary>
        /// <param name="form">Form1 que va a seguir el flujo de la clase</param>
        public void ConfiguraMenu(Form1 form)
        {
            //Vamos a buscar el tabcontrol y la pestaña menu para trabajar con ellas
             Control miComponente = form.Controls["tb_Principal"];
             tabControl = (TabControl)miComponente;

            Control miComponente2 = tabControl.TabPages["tbpage_Menu"];
            TabPage PestañaMenu = (TabPage)miComponente2;

            //Ahora vamos a crear el datagridview del menu y añadirlo a la tabpage menu
            dg_Menu = controles.CreaDatagridView(Nombre_dg_Menu, tamaño_dg_Menu, localizacion_dg_Menu);
            PestañaMenu.Controls.Add(dg_Menu);

            //Vamos a hacer que el tamaño del datagridview ocupe toda la pestaña
            dg_Menu.Dock = DockStyle.Fill;
            dg_Menu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //Ahora enlazamos nuestro datagridview al datatable que queremos que muestre
            MuestraMenu(dg_Menu);

            //Ahora vamos a crear el evento CellClick en el datagridview para poder trabajar con el
            dg_Menu.CellClick += new DataGridViewCellEventHandler(dg_menu_CellClick);
        }

        /// <summary>
        /// Metodo que muestra una consulta con todas sql con todas las tablas de la BBDD gestion_almacen y lo asigna a un datagridview
        /// </summary>
        /// <param name="data">Datagridview que va a mostrar la consulta</param>
        public void MuestraMenu(DataGridView data)
        {

            dt.Clear();
            //dt.Reset();
            ConexionMenu.Open();

            //string consulta = "show tables from gestion_almacen"; hemos encontrado una mejor consulta
            string consulta = "SELECT table_name AS nombre " +
                "FROM information_schema.tables " +
                "WHERE table_schema = 'gestion_almacen' " +
                "AND table_name <> 'ubicacion_articulo' " +
                "AND TABLE_TYPE <> 'VIEW' ;";

            MySqlCommand cmd = new MySqlCommand(consulta, ConexionMenu);
            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);

            adapter.Fill(dt);
            data.DataSource = dt;
            data.AutoResizeColumns();

            ConexionMenu.Close();


            // Establecer la propiedad DataSource del DataGridView en el objeto DataTable
            //data.DataSource = dt;
        }

        /// <summary>
        /// Evento que se inicia cuando se pulsa una celda del datagridview de la pestaña menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dg_menu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            // Verifica si se hizo clic en una celda válida (no en los encabezados)
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtén la celda seleccionada
                DataGridViewCell cell = dg_Menu.Rows[e.RowIndex].Cells[e.ColumnIndex];

                // Verifica si la celda tiene un valor
                if (cell.Value != null)
                {
                    // Guarda el valor de la celda en un string
                    string valorCelda = cell.Value.ToString();
                    claseflujo.AbreTablaGestion_Almacen(valorCelda,tabControl);

                }
            }

                
            //tabcontrol.SelectedTab = PestañaTabla; Esta linea de codigo aqui funciona, pero si lo hacemos en el metodo de la clase flujo en cambio no funciona. Porque? buena pregunta
        }

       

        
    }
}
